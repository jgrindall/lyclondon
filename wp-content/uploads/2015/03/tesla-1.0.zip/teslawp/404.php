<?php get_header(); ?>

<div class="wrapper">
    <div class="titleContainer font1 titlePage titleBordered">
        <div class="title">
            <?php _e('oops, 404','teslawp'); ?>
        </div>
    </div>
    <img class="img404 bgcolor" src="<?php echo get_template_directory_uri(); ?>/images/404.png" alt="">
</div>

<?php get_footer(); ?>