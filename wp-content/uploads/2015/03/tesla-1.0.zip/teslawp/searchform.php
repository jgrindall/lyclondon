<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
	<input type="text" value="<?php _e('Search','teslawp'); ?>" onclick="value=''" name="s" id="s" />
	<input type="submit" id="searchsubmit" value="<?php _e('Search','teslawp'); ?>" />
</form>
