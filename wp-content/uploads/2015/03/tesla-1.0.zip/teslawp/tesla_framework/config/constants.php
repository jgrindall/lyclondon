<?php

define('TT_PREFIX', 'TT_');
define('TT_LOW', 'tt_'); //prefix lowered
define('TT_THEME_DIR', get_template_directory());
define('TT_THEME_URI', get_template_directory_uri());

define ('TT_FW',TT_THEME_URI . '/tesla_framework');
define ('TT_FW_DIR',TT_THEME_DIR . '/tesla_framework');
define('TT_FW_VERSION', '1.0');